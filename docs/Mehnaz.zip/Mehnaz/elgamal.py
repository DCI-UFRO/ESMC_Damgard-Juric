# elgamal.py
import random
from sympy import randprime, mod_inverse


def generate_keys(bits):
    """
    Genera un par ElGamal en un primo p de 'bits' bits.
    Devuelve (p, g, h, x) donde
      - p es primo,
      - g es raíz primitiva,
      - x es clave privada en [1, p-2],
      - h = g^x mod p es clave pública.
    """
    lower = 2**(bits-1)
    upper = 2**bits
    p = randprime(lower, upper)
    while True:
        g = random.randrange(2, p-1)
        if pow(g, (p-1)//2, p) != 1:
            break
    x = random.randrange(1, p-1)
    h = pow(g, x, p)
    return {'p': p, 'g': g, 'h': h, 'x': x}


def elgamal_encrypt(m, pub):
    p, g, h = pub['p'], pub['g'], pub['h']
    r = random.randrange(1, p-1)
    c1 = pow(g, r, p)
    c2 = (pow(h, r, p) * (m % p)) % p
    return (c1, c2)


def elgamal_decrypt(c, priv):
    p, x = priv['p'], priv['x']
    c1, c2 = c
    s = pow(c1, x, p)
    m = (c2 * mod_inverse(s, p)) % p
    return m


def multilayer_encrypt(m, pub_sequence):
    """
    Aplica elgamal_encrypt de forma anidada sobre pub_sequence:
    empieza cifrando con pub_sequence[0], luego pub_sequence[1], ..., pub_sequence[-1].
    Devuelve la cadena de tuplas (c1,c2).
    """
    c = m
    chain = []
    for pub in pub_sequence:
        c_enc = elgamal_encrypt(c, pub)
        chain.append(c_enc)
        c = c  # No dummy decrypt
    return chain


def peel_one_layer(chain, priv):
    *rest, top = chain
    m = elgamal_decrypt(top, priv)
    return rest, m


def serialize_chain(chain):
    """Convierte una lista de tuplas (c1,c2) a lista de dicts serializables."""
    return [{'c1': c1, 'c2': c2} for c1, c2 in chain]


def deserialize_chain(serialized):
    """Convierte una lista de dicts a lista de tuplas (c1,c2)."""
    return [(item['c1'], item['c2']) for item in serialized]
