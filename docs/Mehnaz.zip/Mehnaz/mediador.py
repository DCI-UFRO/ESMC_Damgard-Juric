# mediador.py

# Definición de IPs
IP_P1 = "IP"
IP_P2 = "IP"
IP_P3 = "IP"
IP_MEDIADOR = "IP"

import zmq, random, time, sys
from elgamal import generate_keys, peel_one_layer, elgamal_decrypt

ctx = zmq.Context()

# === INICIO DEL PROGRAMA ===
tiempo_inicio_total = time.time()

# Handshake robusto: esperar READY de todos los participantes
handshake_pull = ctx.socket(zmq.PULL)
handshake_pull.bind(f"tcp://{IP_MEDIADOR}:6010")
print("[Med][DEBUG] Esperando handshake de participantes...")
ready_participants = set()
expected = {"P1", "P2", "P3"}
while ready_participants != expected:
    msg = handshake_pull.recv_json()
    print(f"[Med][DEBUG] Recibido handshake de {msg['id']}")
    ready_participants.add(msg["id"])
print("[Med][DEBUG] Todos los participantes listos. Iniciando protocolo.")
handshake_pull.close()

# --- AHORA crea los sockets PUB/SUB ---
pub_keys = ctx.socket(zmq.PUB)
pub_keys.bind(f"tcp://{IP_MEDIADOR}:6000")
sub_keys = ctx.socket(zmq.SUB)
sub_keys.connect(f"tcp://{IP_MEDIADOR}:6000")
sub_keys.setsockopt_string(zmq.SUBSCRIBE, "")

time.sleep(1)  # Espera para que los SUB se conecten correctamente

# 1) Esperar claves públicas de todos los participantes
tiempo_inicio_espera_claves = time.time()
pull_pubkeys = ctx.socket(zmq.PULL)
pull_pubkeys.bind(f"tcp://{IP_MEDIADOR}:6020")
print("[Med][DEBUG] Esperando claves públicas de los participantes...")
pubs = {}
while len(pubs) < 3:
    msg = pull_pubkeys.recv_json()
    pubs[msg['id']] = {'p': msg['p'], 'g': msg['g'], 'h': msg['h']}
pull_pubkeys.close()
tiempo_fin_espera_claves = time.time()
tiempo_espera_claves = tiempo_fin_espera_claves - tiempo_inicio_espera_claves
print("[Med][DEBUG] Claves públicas recibidas de todos los participantes.")

# 2) Generar su propia clave pública
tiempo_inicio_gen_clave = time.time()
my_keys = generate_keys(2048)
tiempo_fin_gen_clave = time.time()
tiempo_gen_clave = tiempo_fin_gen_clave - tiempo_inicio_gen_clave
modulo_bits = my_keys['p'].bit_length()
pubs['mediador'] = {'p': my_keys['p'], 'g': my_keys['g'], 'h': my_keys['h']}
print("[Med][DEBUG] Clave pública del mediador generada.")

# 3) Enviar todas las claves públicas a cada participante
tiempo_inicio_envio_claves = time.time()
for pid, ip in zip(['P1', 'P2', 'P3'], [IP_P1, IP_P2, IP_P3]):
    push_allpubs = ctx.socket(zmq.PUSH)
    push_allpubs.connect(f"tcp://{ip}:6021")
    push_allpubs.send_json(pubs)
    push_allpubs.close()
    print(f"[Med][DEBUG] Todas las claves públicas enviadas a {pid}.")
tiempo_fin_envio_claves = time.time()
tiempo_envio_claves = tiempo_fin_envio_claves - tiempo_inicio_envio_claves

# Handshake para canal de mezcla: esperar que P3 esté listo para recibir
print("[Med][DEBUG] Esperando handshake de P3 para canal de mezcla...")
handshake_mix_pull = ctx.socket(zmq.PULL)
handshake_mix_pull.bind(f"tcp://{IP_MEDIADOR}:6102")  # P3 hará connect a este puerto para handshake
msg = handshake_mix_pull.recv_json()
if msg.get("ready"):
    print("[Med][DEBUG] P3 está listo para recibir mezcla.")
handshake_mix_pull.close()

# — PULL/PUSH para mezclas —
pull_in = ctx.socket(zmq.PULL)
pull_in.bind(f"tcp://{IP_MEDIADOR}:6001")
push_out = ctx.socket(zmq.PUSH)
push_out.connect(f"tcp://{IP_P3}:6002")  # P3 escucha aquí

# 4) Recibe los 9 “chain” cifrados de los 3 participantes
tiempo_inicio_espera_chains = time.time()
chains = []
for i in range(9):
    print(f"[Med][DEBUG] Esperando chain cifrado {i+1}/9...")
    chains.append(pull_in.recv_json())  # cada uno es lista de 4 pares (c1,c2)
    print(f"[Med][DEBUG] Chain cifrado {i+1}/9 recibido.")
tiempo_fin_espera_chains = time.time()
tiempo_espera_chains = tiempo_fin_espera_chains - tiempo_inicio_espera_chains
tamanio_chains_bytes = sys.getsizeof(chains)
print("[Med] Recibidos 9 ciphertext chains.")
print(f"[Med] Tiempo de espera para recibir chains cifrados (tiempo_espera_chains): {tiempo_espera_chains:.4f} s")

# 5) Mezcla (shuffle) y handshake antes de enviar a P3
tiempo_inicio_mezcla = time.time()
random.shuffle(chains)
tiempo_fin_mezcla = time.time()
tiempo_mezcla = tiempo_fin_mezcla - tiempo_inicio_mezcla

# Handshake: avisar a P3 que se va a enviar la mezcla
print("[Med][DEBUG] Avisando a P3 que se enviará la mezcla...")
handshake_push_out = ctx.socket(zmq.PUSH)
handshake_push_out.connect(f"tcp://{IP_P3}:6102")  # P3 debe tener un PULL en este puerto
handshake_push_out.send_json({"ready": True})
handshake_push_out.close()
print("[Med][DEBUG] Handshake de mezcla enviado a P3.")

# Espera breve para asegurar que el handshake llegue antes del PUSH real
time.sleep(0.5)

push_out.send_json(chains)
print(f"[Med] Tiempo de mezcla y envío a P3 (tiempo_mezcla): {tiempo_mezcla:.4f} s")

# --- Handshake: avisar a P1 que el PULL final está listo ---
print("[Med][DEBUG] Preparando socket PULL para recibir mezcla final de P1...")
pull_final = ctx.socket(zmq.PULL)
pull_final.bind(f"tcp://{IP_MEDIADOR}:{6001+100}")

print("[Med][DEBUG] Avisando a P1 que PULL final está listo...")
handshake_final = ctx.socket(zmq.PUSH)
handshake_final.connect(f"tcp://{IP_P1}:{6001+200}")  # Por ejemplo, 6101+200=6201
handshake_final.send_json({"ready": True})
handshake_final.close()

# --- Esperar mezcla final de P1 ---
tiempo_inicio_espera_final = time.time()
print("[Med][DEBUG] Esperando mezcla final de P1...")
final_chains = pull_final.recv_json()
tiempo_fin_espera_final = time.time()
tiempo_espera_final = tiempo_fin_espera_final - tiempo_inicio_espera_final
print("[Med][DEBUG] Mezcla final recibida de P1.")

print("[Med][DEBUG] Cantidad de chains recibidos:", len(final_chains))
for i, chain in enumerate(final_chains):
    print(f"[Med][DEBUG] Chain {i} longitud: {len(chain)} contenido: {chain}")

# --- Descifrar la última capa y sumar ---
tiempo_inicio_descifrado = time.time()
print("[Med][DEBUG] Descifrando la última capa de cada chain...")
suma = 0
for chain in final_chains:
    # Convierte c1 y c2 a enteros antes de desencriptar
    chain_int = [(int(item['c1']), int(item['c2'])) for item in chain]
    print(f"[Med][DEBUG] Longitud de chain antes de peel: {len(chain_int)}")
    rest_chain, _ = peel_one_layer(chain_int, my_keys)
    print(f"[Med][DEBUG] Longitud de chain después de peel: {len(rest_chain)}")
    if len(rest_chain) == 1:
        c1, c2 = rest_chain[0]
        valor = elgamal_decrypt((c1, c2), my_keys)
        # Ajuste: Si el valor descifrado es mayor que p//2, probablemente es un wrap-around negativo
        p = my_keys['p']
        if valor > p // 2:
            print(f"[Med][WARN] Valor descifrado mayor que p//2, ajustando: {valor} -> {valor - p}")
            valor = valor - p
        print(f"[Med][DEBUG] Valor descifrado: {valor}")
        suma += valor
    elif len(rest_chain) == 0:
        # Si no queda ninguna capa, desencripta directamente el último par recibido
        c1, c2 = chain_int[-1]
        valor = elgamal_decrypt((c1, c2), my_keys)
        p = my_keys['p']
        if valor > p // 2:
            print(f"[Med][WARN] Valor descifrado mayor que p//2, ajustando: {valor} -> {valor - p}")
            valor = valor - p
        print(f"[Med][DEBUG] Valor descifrado (sin capas): {valor}")
        suma += valor
    else:
        print("[Med][ERROR] La chain no tiene la longitud esperada (0 o 1). Se omite esta chain.")
        continue
tiempo_fin_descifrado = time.time()
tiempo_descifrado = tiempo_fin_descifrado - tiempo_inicio_descifrado

print(f"[Med][DEBUG] Suma total de los secretos: {suma}")

# --- Distribuir la suma a todos los participantes con handshake ---
tiempo_inicio_envio_suma = time.time()
for pid, ip in zip(['P1', 'P2', 'P3'], [IP_P1, IP_P2, IP_P3]):
    # Handshake: esperar que el participante esté listo para recibir la suma
    print(f"[Med][DEBUG] Esperando handshake de {pid} para enviar suma...")
    handshake_sum_pull = ctx.socket(zmq.PULL)
    handshake_sum_pull.bind(f"tcp://{IP_MEDIADOR}:{6022 + int(pid[-1])}")  # Ejemplo: 6023, 6024, 6025
    msg = handshake_sum_pull.recv_json()
    if msg.get("ready"):
        print(f"[Med][DEBUG] {pid} está listo para recibir la suma.")
    handshake_sum_pull.close()

    # Enviar suma
    push_sum = ctx.socket(zmq.PUSH)
    push_sum.connect(f"tcp://{ip}:{6022}")
    push_sum.send_json({"suma": suma})
    push_sum.close()
    print(f"[Med][DEBUG] Suma enviada a {pid}.")
tiempo_fin_envio_suma = time.time()
tiempo_envio_suma = tiempo_fin_envio_suma - tiempo_inicio_envio_suma

# === FIN DEL PROGRAMA ===
tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_total

# === TABLA RESUMEN ===
print("\n" + "="*45)
print("RESUMEN DE TIEMPOS Y TAMAÑOS (MEDIADOR)")
print("="*45)
print(f"{'Tamaño del módulo (bits)':38}: {modulo_bits}")
print(f"{'Tiempo espera claves públicas (s)':38}: {tiempo_espera_claves:.4f}")
print(f"{'Tiempo generación de clave propia (s)':38}: {tiempo_gen_clave:.4f}")
print(f"{'Tiempo envío de claves públicas (s)':38}: {tiempo_envio_claves:.4f}")
print(f"{'Tiempo espera chains cifrados (s)':38}: {tiempo_espera_chains:.4f}")
print(f"{'Tamaño de chains recibidos (bytes)':38}: {tamanio_chains_bytes}")
print(f"{'Tiempo de mezcla (s)':38}: {tiempo_mezcla:.4f}")
print(f"{'Tiempo espera mezcla final de P1 (s)':38}: {tiempo_espera_final:.4f}")
print(f"{'Tiempo de descifrado y suma (s)':38}: {tiempo_descifrado:.4f}")
print(f"{'Tiempo de envío de suma (s)':38}: {tiempo_envio_suma:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")
