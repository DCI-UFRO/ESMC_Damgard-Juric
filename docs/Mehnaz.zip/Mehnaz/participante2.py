#### participante2.py
import zmq
import pandas as pd
import random
import json
import time
import sys
from elgamal import generate_keys, multilayer_encrypt, peel_one_layer

# Definición de IPs
IP_P1 = "IP"
IP_P2 = "IP"
IP_P3 = "IP"
IP_MEDIADOR = "IP"

ID = 'P2'
PORT_MIX_IN = 6003  # recibe de P3
PORT_MIX_OUT = 6004  # envía a P1
MED_PULL_PORT = 6001

topics_ctx = zmq.Context()

# Handshake robusto: avisar al mediador que este participante está listo
handshake_push = topics_ctx.socket(zmq.PUSH)
handshake_push.connect(f"tcp://{IP_MEDIADOR}:6010")
handshake_push.send_json({"id": "P2"})
print("[P2][DEBUG] Handshake enviado al mediador, esperando inicio del protocolo.")
handshake_push.close()

# === INICIO DEL PROGRAMA ===
tiempo_inicio_total = time.time()

# 1) Generar clave pública
tiempo_inicio_gen_clave = time.time()
my_keys = generate_keys(2048)
tiempo_fin_gen_clave = time.time()
tiempo_gen_clave = tiempo_fin_gen_clave - tiempo_inicio_gen_clave
modulo_bits = my_keys['p'].bit_length()
clave_pub = {'id': ID, 'p': my_keys['p'], 'g': my_keys['g'], 'h': my_keys['h']}

# 2) Enviar clave pública al mediador
tiempo_inicio_envio_clave = time.time()
push_pubkey = topics_ctx.socket(zmq.PUSH)
push_pubkey.connect(f"tcp://{IP_MEDIADOR}:6020")
push_pubkey.send_json(clave_pub)
push_pubkey.close()
tiempo_fin_envio_clave = time.time()
tiempo_envio_clave = tiempo_fin_envio_clave - tiempo_inicio_envio_clave
print(f"[{ID}][DEBUG] Clave pública enviada al mediador.")

# 3) Esperar todas las claves públicas del mediador
tiempo_inicio_espera_claves = time.time()
pull_allpubs = topics_ctx.socket(zmq.PULL)
pull_allpubs.bind(f"tcp://{globals()['IP_'+ID]}:6021")
print(f"[{ID}][DEBUG] Esperando todas las claves públicas del mediador...")
all_pubs = pull_allpubs.recv_json()
pull_allpubs.close()
tiempo_fin_espera_claves = time.time()
tiempo_espera_claves = tiempo_fin_espera_claves - tiempo_inicio_espera_claves
print(f"[{ID}][DEBUG] Todas las claves públicas recibidas: {list(all_pubs.keys())}")

# 4) Leer y dividir secreto
tiempo_inicio_lectura = time.time()
df = pd.read_csv(f"datos_{ID}.csv")
secret = int(df.select_dtypes(include='number').to_numpy().sum())
tiempo_fin_lectura = time.time()
tiempo_lectura = tiempo_fin_lectura - tiempo_inicio_lectura
print(f"[P2] Tiempo de lectura y suma de CSV (tiempo_lectura): {tiempo_lectura:.4f} s")

tiempo_inicio_particion = time.time()
shares = []
s = secret
for _ in range(2):
    r = random.randrange(0, secret)
    shares.append(r)
    s -= r
shares.append(s)
tiempo_fin_particion = time.time()
tiempo_particion = tiempo_fin_particion - tiempo_inicio_particion
print(f"[P2] Tiempo de partición del secreto (tiempo_particion): {tiempo_particion:.4f} s")

# 5) Cifrar shares en 4 capas
pub_sequence = [all_pubs['mediador'], all_pubs['P1'], all_pubs['P2'], all_pubs['P3']]
tiempo_inicio_cifrado = time.time()
chains = [multilayer_encrypt(share, pub_sequence) for share in shares]
tiempo_fin_cifrado = time.time()
tiempo_cifrado = tiempo_fin_cifrado - tiempo_inicio_cifrado
print(f"[P2] Tiempo de cifrado multilayer (tiempo_cifrado): {tiempo_cifrado:.4f} s")

serialized = [[{'c1': c1, 'c2': c2} for c1, c2 in chain] for chain in chains]
tamanio_chains_bytes = sys.getsizeof(serialized)

# 6) Enviar inicial al mediador
tiempo_inicio_envio = time.time()
push_init = topics_ctx.socket(zmq.PUSH)
push_init.connect(f"tcp://{IP_MEDIADOR}:{MED_PULL_PORT}")
for sch in serialized:
    push_init.send_json(sch)
push_init.close()
tiempo_fin_envio = time.time()
tiempo_envio = tiempo_fin_envio - tiempo_inicio_envio
print("[P2][DEBUG] Chains enviados al mediador.")
print(f"[P2] Tiempo de envío de chains al mediador (tiempo_envio): {tiempo_envio:.4f} s")

# 7) Esperar mezcla de P3
print("[P2][DEBUG] Preparando socket PULL para mezcla de P3...")
tiempo_inicio_espera_mezcla = time.time()
pull_mix = topics_ctx.socket(zmq.PULL)
pull_mix.bind(f"tcp://{IP_P2}:{PORT_MIX_IN}")

print("[P2][DEBUG] Avisando a P3 que PULL de mezcla está listo...")
handshake_mix = topics_ctx.socket(zmq.PUSH)
handshake_mix.connect(f"tcp://{IP_P3}:{PORT_MIX_IN+100}")  # Canal handshake, por ejemplo 6103
handshake_mix.send_json({"ready": True})
handshake_mix.close()

print("[P2][DEBUG] Esperando mezcla de P3...")
mixed = pull_mix.recv_json()
pull_mix.close()
tiempo_fin_espera_mezcla = time.time()
tiempo_espera_mezcla = tiempo_fin_espera_mezcla - tiempo_inicio_espera_mezcla
print("[P2][DEBUG] Mezcla recibida de P3.")
print(f"[P2] Tiempo de espera para recibir mezcla de P3 (tiempo_espera_mezcla): {tiempo_espera_mezcla:.4f} s")

# 8) Quitar capa y reenviar a P1
tiempo_inicio_peel = time.time()
output = []
for sch in mixed:
    chain = [(int(i['c1']), int(i['c2'])) for i in sch]
    print(f"[{ID}][DEBUG] Longitud de chain antes de peel: {len(chain)}")
    rest_chain, _ = peel_one_layer(chain, my_keys)
    print(f"[{ID}][DEBUG] Longitud de chain después de peel: {len(rest_chain)}")
    output.append([{'c1': c1, 'c2': c2} for c1, c2 in rest_chain])
tiempo_fin_peel = time.time()
tiempo_peel = tiempo_fin_peel - tiempo_inicio_peel
print(f"[P2] Tiempo de peel y serialización (tiempo_peel): {tiempo_peel:.4f} s")

random.shuffle(output)

# 9) Esperar handshake y enviar mezcla a P1
print("[P2][DEBUG] Esperando handshake de P1 para canal de mezcla...")
tiempo_inicio_envio_mix = time.time()
handshake_wait = topics_ctx.socket(zmq.PULL)
handshake_wait.bind(f"tcp://{IP_P2}:{PORT_MIX_OUT+100}")  # Debe coincidir con el connect de P1
msg = handshake_wait.recv_json()
if msg.get("ready"):
    print("[P2][DEBUG] P1 está listo para recibir mezcla.")
handshake_wait.close()

push_out = topics_ctx.socket(zmq.PUSH)
push_out.connect(f"tcp://{IP_P1}:{PORT_MIX_OUT}")
push_out.send_json(output)
push_out.close()
tiempo_fin_envio_mix = time.time()
tiempo_envio_mix = tiempo_fin_envio_mix - tiempo_inicio_envio_mix
print(f"[P2] Tiempo de envío de mezcla a P1 (tiempo_envio_mix): {tiempo_envio_mix:.4f} s")

# 10) Esperar suma final del mediador
print(f"[{ID}][DEBUG] Preparando socket PULL para recibir suma del mediador...")
tiempo_inicio_espera_suma = time.time()
pull_sum = topics_ctx.socket(zmq.PULL)
pull_sum.bind(f"tcp://{globals()['IP_'+ID]}:6022")

# Handshake: avisar al mediador que el PULL está listo
print(f"[{ID}][DEBUG] Avisando al mediador que PULL de suma está listo...")
handshake_sum = topics_ctx.socket(zmq.PUSH)
handshake_sum.connect(f"tcp://{IP_MEDIADOR}:{6022 + int(ID[-1])}")
handshake_sum.send_json({"ready": True})
handshake_sum.close()

print(f"[{ID}][DEBUG] Esperando suma total del mediador...")
msg = pull_sum.recv_json()
pull_sum.close()
tiempo_fin_espera_suma = time.time()
tiempo_espera_suma = tiempo_fin_espera_suma - tiempo_inicio_espera_suma
print(f"[{ID}][DEBUG] Suma total recibida del mediador: {msg['suma']}")
print(f"[{ID}] SUMA FINAL: {msg['suma']}")

# === FIN DEL PROGRAMA ===
tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_total

# === TABLA RESUMEN ===
print("\n" + "="*45)
print(f"RESUMEN DE TIEMPOS Y TAMAÑOS ({ID})")
print("="*45)
print(f"{'Tamaño del módulo (bits)':38}: {modulo_bits}")
print(f"{'Tiempo generación de clave (s)':38}: {tiempo_gen_clave:.4f}")
print(f"{'Tiempo envío clave pública (s)':38}: {tiempo_envio_clave:.4f}")
print(f"{'Tiempo espera claves públicas (s)':38}: {tiempo_espera_claves:.4f}")
print(f"{'Tiempo lectura CSV (s)':38}: {tiempo_lectura:.4f}")
print(f"{'Tiempo partición secreto (s)':38}: {tiempo_particion:.4f}")
print(f"{'Tiempo cifrado multilayer (s)':38}: {tiempo_cifrado:.4f}")
print(f"{'Tamaño de chains enviados (bytes)':38}: {tamanio_chains_bytes}")
print(f"{'Tiempo envío chains al mediador (s)':38}: {tiempo_envio:.4f}")
print(f"{'Tiempo espera mezcla de P3 (s)':38}: {tiempo_espera_mezcla:.4f}")
print(f"{'Tiempo peel y serialización (s)':38}: {tiempo_peel:.4f}")
print(f"{'Tiempo envío mezcla a P1 (s)':38}: {tiempo_envio_mix:.4f}")
print(f"{'Tiempo espera suma final (s)':38}: {tiempo_espera_suma:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")
