# mediador.py
# Definición de IPs
IP_P1 = "IP"
IP_P2 = "IP"
IP_P3 = "IP"
IP_P4 = "IP"
IP_MEDIADOR = "IP"

import zmq
import random
import time
import sys
from damgard_jurik import keygen, decrypt

ctx = zmq.Context()

# === INICIO DEL PROGRAMA ===
tiempo_inicio_total = time.time()

# 1. Handshake robusto
handshake_pull = ctx.socket(zmq.PULL)
handshake_pull.bind(f"tcp://{IP_MEDIADOR}:6000")
ready_participants = set()
expected = {"P1", "P2", "P3", "P4"}
while ready_participants != expected:
    msg = handshake_pull.recv_json()
    print(f"[Med][DEBUG] Recibido handshake de {msg['id']}")
    ready_participants.add(msg["id"])
print("[Med][DEBUG] Todos los participantes listos. Iniciando protocolo.")
handshake_pull.close()

# 2. Generar clave pública y privada
tiempo_inicio_gen_claves = time.time()
pub_key, priv_key = keygen(2048, s=1)
tiempo_fin_gen_claves = time.time()
tiempo_gen_claves = tiempo_fin_gen_claves - tiempo_inicio_gen_claves
len_n = pub_key['n'].bit_length()
len_g = pub_key['g'].bit_length()

# 3. Difundir clave pública a todos
tiempo_inicio_envio_clave = time.time()
pub = ctx.socket(zmq.PUB)
pub.bind(f"tcp://{IP_MEDIADOR}:5555")
time.sleep(1)
pub.send_json({'n': pub_key['n'], 's': pub_key['s'], 'g': pub_key['g'], 'len_n': len_n, 'g_bits': len_g})
tiempo_fin_envio_clave = time.time()
tiempo_envio_clave = tiempo_fin_envio_clave - tiempo_inicio_envio_clave

# 4. Esperar suma cifrada de P4
pull = ctx.socket(zmq.PULL)
pull.bind(f"tcp://{IP_MEDIADOR}:5556")
tiempo_inicio_espera_respuesta = time.time()
data = pull.recv_json()
tiempo_fin_espera_respuesta = time.time()
tiempo_espera_respuesta = tiempo_fin_espera_respuesta - tiempo_inicio_espera_respuesta
suma_cifrada = data['suma']
print("[Med] Suma cifrada recibida de P4.")

# 5. Desencriptar suma
tiempo_inicio_desencriptar = time.time()
suma = decrypt(suma_cifrada, pub_key, priv_key)
tiempo_fin_desencriptar = time.time()
tiempo_desencriptar = tiempo_fin_desencriptar - tiempo_inicio_desencriptar
print(f"[Med] Suma desencriptada: {suma}")

# 6. Generar y difundir ZKP (simulado)
y, c, z = 123, 456, 789  # Simulación
pub.send_json({'sum': suma, 'y': y, 'c': c, 'z': z})

# === FIN DEL PROGRAMA ===
tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_total

print("\n" + "="*45)
print("RESUMEN DE TIEMPOS Y TAMAÑOS (MEDIADOR)")
print("="*45)
print(f"{'Tamaño del módulo n (bits)':38}: {len_n}")
print(f"{'Tamaño de g (bits)':38}: {len_g}")
print(f"{'Tiempo generación de claves (s)':38}: {tiempo_gen_claves:.4f}")
print(f"{'Tiempo difusión clave pública (s)':38}: {tiempo_envio_clave:.4f}")
print(f"{'Tiempo espera suma cifrada (s)':38}: {tiempo_espera_respuesta:.4f}")
print(f"{'Tiempo desencriptar suma (s)':38}: {tiempo_desencriptar:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")

