# participante1.py
IP_P1 = "IP"
IP_MEDIADOR = "IP"
IP_P2 = "IP"

import zmq
import pandas as pd
import time
import sys
from damgard_jurik import encrypt

ctx = zmq.Context()

# Handshake robusto
handshake_push = ctx.socket(zmq.PUSH)
handshake_push.connect(f"tcp://{IP_MEDIADOR}:6000")
handshake_push.send_json({"id": "P1"})
print("[P1] Handshake enviado al mediador, esperando inicio del protocolo.")
handshake_push.close()

sub = ctx.socket(zmq.SUB)
sub.connect(f"tcp://{IP_MEDIADOR}:5555")
sub.setsockopt_string(zmq.SUBSCRIBE, "")

push = ctx.socket(zmq.PUSH)
push.connect(f"tcp://{IP_P2}:5557")

# === INICIO DEL PROGRAMA ===
tiempo_inicio_suma_privada = time.time()
df = pd.read_csv('datos_part1.csv')
m1 = int(df.select_dtypes(include='number').to_numpy().sum())
tiempo_fin_suma_privada = time.time()
tiempo_suma_privada = tiempo_fin_suma_privada - tiempo_inicio_suma_privada

tiempo_inicio_espera_clave = time.time()
msg = sub.recv_json()
tiempo_fin_espera_clave = time.time()
tiempo_espera_clave = tiempo_fin_espera_clave - tiempo_inicio_espera_clave
pub_key = {'n': msg['n'], 's': msg['s'], 'g': msg['g']}

tiempo_inicio_cifrado = time.time()
c1 = encrypt(m1, pub_key)
tiempo_fin_cifrado = time.time()
tiempo_cifrado = tiempo_fin_cifrado - tiempo_inicio_cifrado

tiempo_inicio_envio = time.time()
push.send_json({'c': c1})
tiempo_fin_envio = time.time()
tiempo_envio = tiempo_fin_envio - tiempo_inicio_envio

pull = ctx.socket(zmq.PULL)
pull.bind(f"tcp://{IP_P1}:5559")
tiempo_inicio_espera_respuesta = time.time()
data = pull.recv_json()
tiempo_fin_espera_respuesta = time.time()
tiempo_espera_respuesta = tiempo_fin_espera_respuesta - tiempo_inicio_espera_respuesta

tiempo_inicio_validacion_zkp = time.time()
# Simulación de validación ZKP
tiempo_fin_validacion_zkp = time.time()
tiempo_validacion_zkp = tiempo_fin_validacion_zkp - tiempo_inicio_validacion_zkp

tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_suma_privada

print("\n" + "="*45)
print("RESUMEN DE TIEMPOS Y TAMAÑOS (P1)")
print("="*45)
print(f"{'Tamaño del módulo n (bits)':38}: {pub_key['n'].bit_length()}")
print(f"{'Tamaño de g (bits)':38}: {pub_key['g'].bit_length()}")
print(f"{'Tiempo suma privada (s)':38}: {tiempo_suma_privada:.4f}")
print(f"{'Tiempo espera clave pública (s)':38}: {tiempo_espera_clave:.4f}")
print(f"{'Tiempo cifrado del dato privado (s)':38}: {tiempo_cifrado:.4f}")
print(f"{'Tamaño del dato cifrado (bytes)':38}: {sys.getsizeof(c1)}")
print(f"{'Tiempo envío dato cifrado a P2 (s)':38}: {tiempo_envio:.4f}")
print(f"{'Tiempo espera respuesta del mediador (s)':38}: {tiempo_espera_respuesta:.4f}")
print(f"{'Tiempo validación ZKP (s)':38}: {tiempo_validacion_zkp:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")
