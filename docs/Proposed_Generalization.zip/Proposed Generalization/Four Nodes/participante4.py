# participante4.py
IP_P4 = "IP"
IP_P3 = "IP"
IP_MEDIADOR = "IP"

import zmq
import pandas as pd
import time
import sys
from damgard_jurik import encrypt

ctx = zmq.Context()

handshake_push = ctx.socket(zmq.PUSH)
handshake_push.connect(f"tcp://{IP_MEDIADOR}:6000")
handshake_push.send_json({"id": "P4"})
print("[P4] Handshake enviado al mediador, esperando inicio del protocolo.")
handshake_push.close()

sub = ctx.socket(zmq.SUB)
sub.connect(f"tcp://{IP_MEDIADOR}:5555")
sub.setsockopt_string(zmq.SUBSCRIBE, "")

pull = ctx.socket(zmq.PULL)
pull.bind(f"tcp://{IP_P4}:5559")      # P3 → P4

push = ctx.socket(zmq.PUSH)
push.connect(f"tcp://{IP_MEDIADOR}:5556")  # P4 → mediador

tiempo_inicio_suma_privada = time.time()
df = pd.read_csv('datos_part4.csv')
m4 = int(df.select_dtypes(include='number').to_numpy().sum())
tiempo_fin_suma_privada = time.time()
tiempo_suma_privada = tiempo_fin_suma_privada - tiempo_inicio_suma_privada

tiempo_inicio_espera_clave = time.time()
msg = sub.recv_json()
tiempo_fin_espera_clave = time.time()
tiempo_espera_clave = tiempo_fin_espera_clave - tiempo_inicio_espera_clave
pub_key = {'n': msg['n'], 's': msg['s'], 'g': msg['g']}

tiempo_inicio_espera_suma123 = time.time()
data = pull.recv_json()
tiempo_fin_espera_suma123 = time.time()
tiempo_espera_suma123 = tiempo_fin_espera_suma123 - tiempo_inicio_espera_suma123
suma123 = data['suma']
print("[P4] Recibida suma123:", suma123)
print(f"[P4] Tiempo de espera para recibir suma123 (tiempo_espera_suma123): {tiempo_espera_suma123:.4f} s")

tiempo_inicio_cifrado_suma = time.time()
c4 = encrypt(m4, pub_key)
suma1234 = (suma123 * c4) % (pub_key['n'] ** (pub_key['s'] + 1))
tiempo_fin_cifrado_suma = time.time()
tiempo_cifrado_suma = tiempo_fin_cifrado_suma - tiempo_inicio_cifrado_suma
print("[P4] Suma cifrada 1+2+3+4:", suma1234)
print(f"[P4] Tiempo de cifrado y suma (tiempo_cifrado_suma): {tiempo_cifrado_suma:.4f} s")

# Enviar al mediador
tiempo_inicio_envio = time.time()
push.send_json({'suma': suma1234})
tiempo_fin_envio = time.time()
tiempo_envio = tiempo_fin_envio - tiempo_inicio_envio
print(f"[P4] Tiempo de envío de la suma cifrada al mediador (tiempo_envio): {tiempo_envio:.4f} s")

# Validación de ZKP
tiempo_inicio_espera_zkp = time.time()
ctx = zmq.Context()
sub_proof = ctx.socket(zmq.SUB)
sub_proof.connect(f"tcp://{IP_MEDIADOR}:5555")
sub_proof.setsockopt_string(zmq.SUBSCRIBE, "")

msg = sub_proof.recv_json()
tiempo_fin_espera_zkp = time.time()
tiempo_espera_zkp = tiempo_fin_espera_zkp - tiempo_inicio_espera_zkp
print(f"[P4] Tiempo de espera para recibir ZKP (tiempo_espera_zkp): {tiempo_espera_zkp:.4f} s")

sum_plain = msg['sum']
y = msg['y']
c = msg['c']
z = msg['z']

nsq = pub_key['n'] ** 2
tiempo_inicio_validacion_zkp = time.time()
lhs = pow(pub_key['g'], z, nsq)
rhs = (y * pow(pub_key['g'], c * sum_plain, nsq)) % nsq
tiempo_fin_validacion_zkp = time.time()
tiempo_validacion_zkp = tiempo_fin_validacion_zkp - tiempo_inicio_validacion_zkp

if lhs == rhs:
    print("[P4] Prueba válida")
else:
    print("[P4] ¡Prueba inválida!")
print(f"[P4] Tiempo de validación de ZKP (tiempo_validacion_zkp): {tiempo_validacion_zkp:.4f} s")

tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_suma_privada

print("\n" + "="*45)
print("RESUMEN DE TIEMPOS Y TAMAÑOS (P4)")
print("="*45)
print(f"{'Tamaño del módulo n (bits)':38}: {pub_key['n'].bit_length()}")
print(f"{'Tamaño de g (bits)':38}: {pub_key['g'].bit_length()}")
print(f"{'Tiempo suma privada (s)':38}: {tiempo_suma_privada:.4f}")
print(f"{'Tiempo espera clave pública (s)':38}: {tiempo_espera_clave:.4f}")
print(f"{'Tiempo espera suma123 (s)':38}: {tiempo_espera_suma123:.4f}")
print(f"{'Tiempo cifrado y suma (s)':38}: {tiempo_cifrado_suma:.4f}")
print(f"{'Tamaño de suma cifrada enviada (bytes)':38}: {sys.getsizeof(suma1234)}")
print(f"{'Tiempo envío suma cifrada al mediador (s)':38}: {tiempo_envio:.4f}")
print(f"{'Tiempo espera ZKP (s)':38}: {tiempo_espera_zkp:.4f}")
print(f"{'Tiempo validación ZKP (s)':38}: {tiempo_validacion_zkp:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")