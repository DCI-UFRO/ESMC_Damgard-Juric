# damgard_jurik.py
import random
import math
import sympy

def lcm(a, b):
    return abs(a * b) // math.gcd(a, b)

def L(u, n):
    return (u - 1) // n

def generate_keys(bits, s):
    lower_bound = 2 ** ((bits // 2) - 1)
    upper_bound = 2 ** (bits // 2)
    p = sympy.randprime(lower_bound, upper_bound)
    q = sympy.randprime(lower_bound, upper_bound)
    n = p * q
    g = n + 1
    lambda_val = lcm(p - 1, q - 1)
    ns_plus = n ** (s + 1)
    u = pow(g, lambda_val, ns_plus)
    L_u = L(u, n)
    mu = sympy.mod_inverse(L_u, n)
    return {'n': n, 's': s, 'g': g, 'lambda': lambda_val, 'mu': mu}

def key_lengths(pub):
    """ Devuelve la longitud en bits de n y de la clave pública. """
    n = pub['n']
    # longitud del módulo
    len_n = n.bit_length()
    # longitud de la clave pública (g)
    len_g = pub['g'].bit_length()
    return len_n, len_g

def encrypt(m, public_key):
    n, s, g = public_key['n'], public_key['s'], public_key['g']
    ns_plus = n ** (s + 1)
    while True:
        r = random.randrange(1, n)
        if math.gcd(r, n) == 1:
            break
    c = (pow(g, m, ns_plus) * pow(r, n ** s, ns_plus)) % ns_plus
    return c

def decrypt(c, private_key):
    n, s = private_key['n'], private_key['s']
    ns_plus = n ** (s + 1)
    lambda_val, mu = private_key['lambda'], private_key['mu']
    u = pow(c, lambda_val, ns_plus)
    L_u = L(u, n)
    return (L_u * mu) % n

