# mediador.py
# Definición de IPs
IP_P1 = "IP"
IP_P2 = "IP"
IP_P3 = "IP"
IP_MEDIADOR = "IP"

import zmq
import hashlib
import random
import time
from damgard_jurik import generate_keys, key_lengths, decrypt

# Configuración ZeroMQ
ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.bind(f"tcp://{IP_MEDIADOR}:5555")       # para difundir clave pública
pull = ctx.socket(zmq.PULL)
pull.bind(f"tcp://{IP_MEDIADOR}:5556")      # para recibir suma cifrada final

tiempo_inicio_total = time.time()

# Handshake robusto: esperar READY de todos los participantes
handshake_pull = ctx.socket(zmq.PULL)
handshake_pull.bind(f"tcp://{IP_MEDIADOR}:6000")
print("[Med] Esperando handshake de participantes...")
ready_participants = set()
expected = {"P1", "P2", "P3"}
while ready_participants != expected:
    msg = handshake_pull.recv_json()
    print(f"[Med] Recibido handshake de {msg['id']}")
    ready_participants.add(msg["id"])
print("[Med] Todos los participantes listos. Iniciando protocolo.")
handshake_pull.close()

# 1) Generar claves
bits, s = 2048, 1
tiempo_inicio_gen_claves = time.time()
keys_priv = generate_keys(bits, s)
tiempo_fin_gen_claves = time.time()
tiempo_gen_claves = tiempo_fin_gen_claves - tiempo_inicio_gen_claves
print(f"[Med] Tiempo de generación de claves (tiempo_gen_claves): {tiempo_gen_claves:.4f} s")

pub_key = {k: keys_priv[k] for k in ('n','s','g')}

# 2) Difundir clave pública y longitudes
len_n, len_g = key_lengths(pub_key)
mensaje = {
    'n': pub_key['n'],
    's': pub_key['s'],
    'g': pub_key['g'],
    'len_n': len_n,
    'len_g': len_g
}
print(f"[Med] Difundiendo clave pública: módulo={len_n} bits, g={len_g} bits")

tiempo_inicio_envio_clave = time.time()
pub.send_json(mensaje)
tiempo_fin_envio_clave = time.time()
tiempo_envio_clave = tiempo_fin_envio_clave - tiempo_inicio_envio_clave
print(f"[Med] Tiempo en difundir clave pública (tiempo_envio_clave, incluye red): {tiempo_envio_clave:.4f} s")

# 3) Esperar resultado encadenado
tiempo_inicio_espera_respuesta = time.time()
suma_cifrada = pull.recv_json()['suma']
tiempo_fin_espera_respuesta = time.time()
tiempo_espera_respuesta = tiempo_fin_espera_respuesta - tiempo_inicio_espera_respuesta
print("[Med] Recibido cifrado de la suma:", suma_cifrada)
print(f"[Med] Tiempo de espera para recibir suma cifrada (tiempo_espera_respuesta): {tiempo_espera_respuesta:.4f} s")

# 4) Desencriptar y (más tarde) generar prueba
tiempo_inicio_desencriptar = time.time()
resultado = decrypt(suma_cifrada, keys_priv)
tiempo_fin_desencriptar = time.time()
tiempo_desencriptar = tiempo_fin_desencriptar - tiempo_inicio_desencriptar
print(f"[Med] Texto plano resultante: {resultado}")
print(f"[Med] Tiempo de desencriptación (tiempo_desencriptar): {tiempo_desencriptar:.4f} s")

# --- Parámetros ya disponibles ---
# pub_key = {'n': ..., 's': ..., 'g': ...}
# keys_priv = {..., 'lambda': λ, ...}
# suma_cifrada recibido en y3, resultado = sum = decrypt(y3,...)

n = pub_key['n']
g = pub_key['g']
sum_plain = resultado

# 5) Generar prueba de Schnorr no interactiva
# 5.1 Elegir r <- Z_n al azar
r = random.randrange(0, n)
# 5.2 Calcular y = g^r mod n^2
nsq = n**2
y = pow(g, r, nsq)
# 5.3 Calcular c = H(y) mod n  (Fiat–Shamir transform)
#    Usamos SHA-256 como función hash
hash_y = hashlib.sha256(str(y).encode()).digest()
c = int.from_bytes(hash_y, 'big') % n
# 5.4 Calcular z = r + c * sum_plain  mod n
z = (r + c * sum_plain) % n

# 6) Difundir (sum_plain, y, c, z)
pub.send_json({
    'sum': sum_plain,
    'y': y,
    'c': c,
    'z': z
})
print(f"[Med] Enviado tuple (sum={sum_plain}, y={y}, c={c}, z={z})")

# === FIN DEL PROGRAMA ===
tiempo_fin_total = time.time()
tiempo_total = tiempo_fin_total - tiempo_inicio_total

print("\n" + "="*45)
print("RESUMEN DE TIEMPOS Y TAMAÑOS (MEDIADOR)")
print("="*45)
print(f"{'Tamaño del módulo n (bits)':38}: {len_n}")
print(f"{'Tamaño de g (bits)':38}: {len_g}")
print(f"{'Tiempo generación de claves (s)':38}: {tiempo_gen_claves:.4f}")
print(f"{'Tiempo difusión clave pública (s)':38}: {tiempo_envio_clave:.4f}")
print(f"{'Tiempo espera suma cifrada (s)':38}: {tiempo_espera_respuesta:.4f}")
print(f"{'Tiempo desencriptar suma (s)':38}: {tiempo_desencriptar:.4f}")
print(f"{'Tiempo total de ejecución (s)':38}: {tiempo_total:.4f}")
print("="*45 + "\n")

