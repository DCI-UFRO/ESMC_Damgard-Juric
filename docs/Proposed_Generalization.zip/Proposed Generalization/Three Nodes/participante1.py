# participante1.py
# Definición de IPs
IP_P1 = "IP"
IP_P2 = "IP"
IP_MEDIADOR = "IP"

import zmq
import hashlib
import random, math
from damgard_jurik import encrypt
import pandas as pd
import time

ctx = zmq.Context()

# Handshake robusto: avisar al mediador que este participante está listo
handshake_push = ctx.socket(zmq.PUSH)
handshake_push.connect(f"tcp://{IP_MEDIADOR}:6000")
handshake_push.send_json({"id": "P1"})  # Cambia "P1" por "P2" o "P3" según corresponda
print("[P1] Handshake enviado al mediador, esperando inicio del protocolo.")
handshake_push.close()

sub = ctx.socket(zmq.SUB)
sub.connect(f"tcp://{IP_MEDIADOR}:5555")
sub.setsockopt_string(zmq.SUBSCRIBE, "")

push = ctx.socket(zmq.PUSH)
push.connect(f"tcp://{IP_MEDIADOR}:5556")      # finalmente al mediador

def get_private_value(csv_path: str) -> int:
    df = pd.read_csv(csv_path)
    numeric_df = df.select_dtypes(include='number')
    return int(numeric_df.to_numpy().sum())

# 1) Obtención de dato privado desde CSV y medición de tiempo
csv_path = 'datos_part1.csv'
tiempo_inicio_suma_privada = time.time()
m1 = get_private_value(csv_path)
tiempo_fin_suma_privada = time.time()
tiempo_suma_privada = tiempo_fin_suma_privada - tiempo_inicio_suma_privada
print(f"[P1] Valor privado (sumatorio de '{csv_path}') = {m1}")
print(f"[P1] Tiempo de cálculo de suma privada (tiempo_suma_privada): {tiempo_suma_privada:.4f} s")

# 2) Recibir clave pública
msg = sub.recv_json()
pub_key = {'n': msg['n'], 's': msg['s'], 'g': msg['g']}
print("[P1] Recibida clave pública. n bits:", msg['len_n'])

# 3) Encriptar dato privado y medir tiempo
tiempo_inicio_cifrado = time.time()
c1 = encrypt(m1, pub_key)
tiempo_fin_cifrado = time.time()
tiempo_cifrado = tiempo_fin_cifrado - tiempo_inicio_cifrado
print("[P1] Cifrado m1:", c1)
print(f"[P1] Tiempo de cifrado del dato privado (tiempo_cifrado): {tiempo_cifrado:.4f} s")

# 4) Enviar a P2 vía push/pull intermedio y medir tiempo de envío
push_to_p2 = ctx.socket(zmq.PUSH)
push_to_p2.connect(f"tcp://{IP_P2}:5557")  # P2 PULL

tiempo_inicio_envio = time.time()
push_to_p2.send_json({'c': c1})
tiempo_fin_envio = time.time()
tiempo_envio = tiempo_fin_envio - tiempo_inicio_envio
print(f"[P1] Tiempo de envío del dato cifrado a P2 (tiempo_envio): {tiempo_envio:.4f} s")

# 5) Medir tiempo de espera de respuesta del servidor (mediador)
tiempo_inicio_espera_respuesta = time.time()
sub_proof = ctx.socket(zmq.SUB)
sub_proof.connect(f"tcp://{IP_MEDIADOR}:5555")
sub_proof.setsockopt_string(zmq.SUBSCRIBE, "")

msg = sub_proof.recv_json()
tiempo_fin_espera_respuesta = time.time()
tiempo_espera_respuesta = tiempo_fin_espera_respuesta - tiempo_inicio_espera_respuesta
print(f"[P1] Tiempo de espera para recibir respuesta del mediador (tiempo_espera_respuesta): {tiempo_espera_respuesta:.4f} s")

sum_plain = msg['sum']
y = msg['y']
c = msg['c']
z = msg['z']

# 6) Validación de ZKP y medición de tiempo
nsq = pub_key['n'] ** 2
tiempo_inicio_validacion_zkp = time.time()
lhs = pow(pub_key['g'], z, nsq)
rhs = (y * pow(pub_key['g'], c * sum_plain, nsq)) % nsq
tiempo_fin_validacion_zkp = time.time()
tiempo_validacion_zkp = tiempo_fin_validacion_zkp - tiempo_inicio_validacion_zkp

# Verificación: g^z ?= y * g^{c * sum}  mod n^2
if lhs == rhs:
    print("[P1] Prueba ZKP válida")
else:
    print("[P1] ¡Prueba ZKP inválida!")
print(f"[P1] Tiempo de validación de ZKP (tiempo_validacion_zkp): {tiempo_validacion_zkp:.4f} s")
