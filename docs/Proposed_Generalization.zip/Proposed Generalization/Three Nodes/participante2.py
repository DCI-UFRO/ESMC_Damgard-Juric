# participante2.py
# Definición de IPs
IP_P2 = "IP"
IP_P3 = "IP"
IP_MEDIADOR = "IP"

import zmq
import hashlib
import random, math
from damgard_jurik import encrypt
import pandas as pd
import time

ctx = zmq.Context()

# Handshake robusto: avisar al mediador que este participante está listo
handshake_push = ctx.socket(zmq.PUSH)
handshake_push.connect(f"tcp://{IP_MEDIADOR}:6000")
handshake_push.send_json({"id": "P2"})  # Cambia "P1" por "P2" o "P3" según corresponda
print("[P2] Handshake enviado al mediador, esperando inicio del protocolo.")
handshake_push.close()

sub = ctx.socket(zmq.SUB)
sub.connect(f"tcp://{IP_MEDIADOR}:5555")
sub.setsockopt_string(zmq.SUBSCRIBE, "")

pull = ctx.socket(zmq.PULL)
pull.bind(f"tcp://{IP_P2}:5557")      # P1 → P2

push = ctx.socket(zmq.PUSH)
push.connect(f"tcp://{IP_P3}:5558")  # P3 PULL

def get_private_value(csv_path: str) -> int:
    df = pd.read_csv(csv_path)
    numeric_df = df.select_dtypes(include='number')
    return int(numeric_df.to_numpy().sum())

# Obtención de dato privado desde CSV
#    El archivo puede tener varias columnas (vertical) o muchas filas (horizontal).
tiempo_inicio_suma_privada = time.time()
csv_path = 'datos_part2.csv'
m2 = get_private_value(csv_path)
tiempo_fin_suma_privada = time.time()
tiempo_suma_privada = tiempo_fin_suma_privada - tiempo_inicio_suma_privada
print(f"[P2] Valor privado (sumatorio de '{csv_path}') = {m2}")
print(f"[P2] Tiempo de cálculo de suma privada (tiempo_suma_privada): {tiempo_suma_privada:.4f} s")

# Recibir clave
tiempo_inicio_espera_clave = time.time()
msg = sub.recv_json()
tiempo_fin_espera_clave = time.time()
tiempo_espera_clave = tiempo_fin_espera_clave - tiempo_inicio_espera_clave
pub_key = {'n': msg['n'], 's': msg['s'], 'g': msg['g']}
print(f"[P2] Tiempo de espera para recibir clave pública (tiempo_espera_clave): {tiempo_espera_clave:.4f} s")

# Recibir c1
tiempo_inicio_espera_c1 = time.time()
data = pull.recv_json()
tiempo_fin_espera_c1 = time.time()
tiempo_espera_c1 = tiempo_fin_espera_c1 - tiempo_inicio_espera_c1
c1 = data['c']
print("[P2] Recibido c1:", c1)
print(f"[P2] Tiempo de espera para recibir c1 (tiempo_espera_c1): {tiempo_espera_c1:.4f} s")

# Encriptar m2 y sumar
tiempo_inicio_cifrado_suma = time.time()
c2 = encrypt(m2, pub_key)
suma12 = (c1 * c2) % (pub_key['n'] ** (pub_key['s'] + 1))
tiempo_fin_cifrado_suma = time.time()
tiempo_cifrado_suma = tiempo_fin_cifrado_suma - tiempo_inicio_cifrado_suma
print("[P2] Suma cifrada 1+2:", suma12)
print(f"[P2] Tiempo de cifrado y suma (tiempo_cifrado_suma): {tiempo_cifrado_suma:.4f} s")

# Enviar a P3
tiempo_inicio_envio = time.time()
push.send_json({'c': suma12})
tiempo_fin_envio = time.time()
tiempo_envio = tiempo_fin_envio - tiempo_inicio_envio
print(f"[P2] Tiempo de envío de la suma cifrada a P3 (tiempo_envio): {tiempo_envio:.4f} s")

# Validación de ZKP
tiempo_inicio_espera_zkp = time.time()
sub_proof = ctx.socket(zmq.SUB)
sub_proof.connect(f"tcp://{IP_MEDIADOR}:5555")
sub_proof.setsockopt_string(zmq.SUBSCRIBE, "")

msg = sub_proof.recv_json()
tiempo_fin_espera_zkp = time.time()
tiempo_espera_zkp = tiempo_fin_espera_zkp - tiempo_inicio_espera_zkp
print(f"[P2] Tiempo de espera para recibir ZKP (tiempo_espera_zkp): {tiempo_espera_zkp:.4f} s")

sum_plain = msg['sum']
y = msg['y']
c = msg['c']
z = msg['z']

# Verificación: g^z ?= y * g^{c * sum}  mod n^2
nsq = pub_key['n'] ** 2
tiempo_inicio_validacion_zkp = time.time()
lhs = pow(pub_key['g'], z, nsq)
rhs = (y * pow(pub_key['g'], c * sum_plain, nsq)) % nsq
tiempo_fin_validacion_zkp = time.time()
tiempo_validacion_zkp = tiempo_fin_validacion_zkp - tiempo_inicio_validacion_zkp

if lhs == rhs:
    print("[P] Prueba válida")
else:
    print("[P] ¡Prueba inválida!")
print(f"[P2] Tiempo de validación de ZKP (tiempo_validacion_zkp): {tiempo_validacion_zkp:.4f} s")
